CREATE TABLE MotionPicture (id INTEGER,
   name CHAR(20),
   rating FLOAT,
   production CHAR(25),
   budget INTEGER,
   PRIMARY KEY (id),
   CHECK (rating >= 0 AND rating <= 10),
   CHECK (budget > 0)
);

CREATE TABLE Users (email CHAR(30),
  name CHAR(30),
  age INTEGER,
  PRIMARY KEY (email)
);

CREATE TABLE Likes (uemail CHAR(20),
  mpid INTEGER,
  PRIMARY KEY (uemail, mpid),
  FOREIGN KEY (uemail) REFERENCES Users(email),
  FOREIGN KEY (mpid) REFERENCES MotionPicture(id)
);

CREATE TABLE Movie (mpid INTEGER,
  boxoffice_collection INTEGER,
  PRIMARY KEY (mpid),
  FOREIGN KEY (mpid) REFERENCES MotionPicture(id)
);

CREATE TABLE Series (mpid INTEGER,
   season_count INTEGER,
   PRIMARY KEY (mpid),
   FOREIGN KEY (mpid) REFERENCES MotionPicture(id)
);




CREATE TABLE People (id INTEGER,
   name CHAR(50),
   nationality CHAR(50), 
   dob VARCHAR(50), 
   gender CHAR(2), 
   PRIMARY KEY(id)
);




CREATE TABLE ROLE (mpid INTEGER,
 pid INTEGER, 
 role_name CHAR(50), 
 PRIMARY KEY	(mpid,pid,role_name),
 FOREIGN KEY	(mpid) REFERENCES MotionPicture(id), 
 FOREIGN KEY	(pid) REFERENCES People(id)
);

CREATE TABLE Award (mpid INTEGER,
  pid INTEGER, 
  award_name CHAR(25), 
  award_year YEAR(4),
  PRIMARY KEY (mpid,pid,award_name,award_year),
  FOREIGN KEY (mpid) REFERENCES MotionPicture(id),
  FOREIGN KEY (pid) REFERENCES People(id)
); 


CREATE TABLE Genre (mpid INTEGER, 
  genre_name CHAR(25), 
  PRIMARY KEY (mpid,genre_name),
  FOREIGN KEY(mpid) REFERENCES MotionPicture(id)
);


CREATE TABLE Location (mpid INTEGER, 
     zip VARCHAR(25), 
     city CHAR(25), 
     country CHAR(25), 
     PRIMARY KEY (mpid,zip), 
     FOREIGN KEY(mpid) REFERENCES MotionPicture(id)
);
